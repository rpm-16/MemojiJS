
function emoji() {
    
    let field = document.body.querySelector('#emoji');
    let cards = field.querySelectorAll("li");
    let pictures = ['🐶', '🐱', '🐭', '🐹', '🐰', '🐻','🐶', '🐱', '🐭', '🐹', '🐰', '🐻'];
    let tmpCard; 

    timer();

    cards.forEach(card => {
        card.addEventListener('click', (event) => {
            event.preventDefault();
            card.classList.toggle('turned');

            // if (tmpCard){
            //     if (event.target.innerHTML == tmpCard) {
            //         event.target.style.display = 'none';
            //         tmpCard = null; 
            //     } else {
            //         tmpCard = event.target.innerHTML;
            //         event.target.classList.toggle('turned');
            //     }
            // } else {
            //     tmpCard = event.target.innerHTML;
            // }
            
        });
    });
}

function timer(){
        let clock = 60;
        document.querySelector('.timer').innerHTML = clock;
};


emoji();